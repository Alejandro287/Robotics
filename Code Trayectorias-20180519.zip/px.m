%%
mdl_phantomx;
px.plot([0 0 0 0])

%%
T = px.fkine([pi/4 pi/4 pi/16 pi/2]);

px.ikunc(T)
%px.ikine(T,[0 0 0 0],[1 1 1 0 1 0]')
%%
T_traj = ctraj(px.fkine([0 pi/16 pi/16 pi/16]),px.fkine([pi/4 pi/4 pi/3 pi/3]),40);
q_ctraj = px.ikunc(T_traj(:,:,:));
figure
hold on
trplot(eye(4),'rgb')
%axis([-3 3 -3 3 -0.5 3])
for i=1:length(q_ctraj)
    punto = px.fkine(q_ctraj(i,:));
    px.plot(q_ctraj(i,:))%,'workspace',[-3 3 -3 3 -0.5 3],'scale',0.5,'jaxes')
    plot3(punto(1,4),punto(2,4),punto(3,4),'r*')
    view(3)
    %pause(0.5)
end
figure
plot(q_ctraj(:,1:4),'linewidth',2)
grid on
legend('q1','q2','q3','q4')
xlabel('Paso de tiempo')